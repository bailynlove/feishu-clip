// {{}} 模板引擎：纯函数、不依赖 chrome API，node:test 可直接测。
// 语法决议见 #30：变量 title/url/host/date/time/datetime/content，
// filter 仅 {{date|date:FORMAT}}（token YYYY MM DD HH mm ss），未知变量/非法 filter 置空。
// digest（#75）：仅 AI 摘要开关开启时由 buildContext 注入自指字面量 '{{digest}}'，
// 让占位符原样穿过渲染进入 snapshot.markdown（{{digest}} 的最终替换发生在 bridge 侧）。

const PLACEHOLDER = /\{\{\s*([^{}]+?)\s*\}\}/g;
const CONTENT_PLACEHOLDER = /\{\{\s*content\s*\}\}/;
const DATE_FILTER = /^date:(.+)$/;
const DATE_VARIABLES = ['date', 'time', 'datetime'];
const DATE_TOKEN = /YYYY|MM|DD|HH|mm|ss/g;
const FILENAME_UNSAFE = /[/\\:*?"<>|\u0000-\u001f\u007f]/g;

function pad(value) {
  return String(value).padStart(2, '0');
}

function localParts(date) {
  return {
    YYYY: String(date.getFullYear()),
    MM: pad(date.getMonth() + 1),
    DD: pad(date.getDate()),
    HH: pad(date.getHours()),
    mm: pad(date.getMinutes()),
    ss: pad(date.getSeconds()),
  };
}

function formatDate(date, format) {
  const parts = localParts(date);
  return format.replace(DATE_TOKEN, (token) => parts[token]);
}

// snapshot 是 extractor 的产出 {title, sourceUrl, capturedAt, markdown, images}
// digestEnabled（#75）：为真时注入 context.digest = '{{digest}}' 自指字面量——占位符原样
// 穿过 renderTemplate 进入 snapshot.markdown（{{ digest }} 等空格写法一并归一），最终替换
// 由 bridge 在完成 AI 摘要后执行；为假时不设 digest 键，走未知变量置空的既有行为
export function buildContext(snapshot, { digestEnabled = false } = {}) {
  const url = typeof snapshot.sourceUrl === 'string' ? snapshot.sourceUrl : '';
  let host = '';
  try {
    host = new URL(url).host;
  } catch {
    host = '';
  }
  const captured = new Date(snapshot.capturedAt);
  const valid = !Number.isNaN(captured.getTime());
  const context = {
    title: typeof snapshot.title === 'string' ? snapshot.title : '',
    url,
    host,
    date: valid ? formatDate(captured, 'YYYY-MM-DD') : '',
    time: valid ? formatDate(captured, 'HH:mm') : '',
    datetime: valid ? formatDate(captured, 'YYYY-MM-DD HH:mm') : '',
    content: typeof snapshot.markdown === 'string' ? snapshot.markdown : '',
  };
  if (digestEnabled) context.digest = '{{digest}}';
  // filter 重排 date/time/datetime 需要原始时间；不可枚举，不影响渲染与断言
  Object.defineProperty(context, '_date', { value: valid ? captured : null, enumerable: false });
  return context;
}

export function renderTemplate(template, ctx) {
  if (typeof template !== 'string') return '';
  return template.replace(PLACEHOLDER, (_match, inner) => {
    const segments = inner.split('|');
    if (segments.length > 2) return '';
    const name = segments[0].trim();
    const filter = segments[1]?.trim();
    if (filter === undefined) {
      const value = ctx[name];
      return typeof value === 'string' ? value : '';
    }
    const match = DATE_FILTER.exec(filter);
    if (!match || !DATE_VARIABLES.includes(name)) return '';
    const date = ctx._date;
    if (!(date instanceof Date) || Number.isNaN(date.getTime())) return '';
    return formatDate(date, match[1].trim());
  });
}

export function renderBody(bodyTemplate, ctx) {
  const content = typeof ctx.content === 'string' ? ctx.content : '';
  if (typeof bodyTemplate !== 'string' || bodyTemplate.trim() === '') return content;
  if (CONTENT_PLACEHOLDER.test(bodyTemplate)) return renderTemplate(bodyTemplate, ctx);
  return `${content}\n\n${renderTemplate(bodyTemplate, ctx)}`;
}

export function renderTitle(titleTemplate, ctx) {
  const rendered = renderTemplate(titleTemplate, ctx);
  const base = rendered.trim() === '' ? (typeof ctx.title === 'string' ? ctx.title : '') : rendered;
  return sanitizeFilename(base);
}

export function sanitizeFilename(name) {
  return String(name ?? '')
    .replace(FILENAME_UNSAFE, '-')
    .trim()
    .replace(/\.+$/, '');
}

// CLIP 携带的手改标题（#36）：非法字符清洗；清洗后为空（空白/纯非法字符/非字符串）
// 返回 null，调用方回退 extractor 标题，绝不把空标题发给 Bridge
export function sanitizeClipTitle(title) {
  if (typeof title !== 'string') return null;
  const cleaned = sanitizeFilename(title);
  return cleaned === '' ? null : cleaned;
}

// 最终正文合成（#37/#40 语义变更后）：有效正文模板 = 弹窗「自定义正文」框内容
// （预填所选预设的 bodyTemplate），合成语义就是 renderBody 本身——含 {{content}}
// 替换占位符、非空无占位符整段追加在后、空白只有正文。弹窗预览与 background 保存
// 都直接调 renderBody，保证预览 === 最终保存内容；不再保留独立的 composeClipBody。
